package prob1;
import java.util.*;
import java.util.Scanner;
public class Patient implements Comparable<Patient>{
protected String name;
protected String ailment;
protected int painLevel;
protected boolean isInNeedOfTreatment;


public Patient(String name, String ailment, int painLevel) {
	// TODO Auto-generated constructor stub
	System.out.println("Patient Name:");
	Scanner input = new Scanner(System.in);
	name = input.nextLine();
	System.out.println("Ailment:");
	ailment = input.nextLine();
	System.out.println("Pain Level:");
	painLevel = input.nextInt();
	
	
	
	this.name = name;
	this.ailment = ailment;
	this.painLevel = painLevel;
	if( painLevel >= 10 || painLevel >= 5){
		isInNeedOfTreatment = true;
}
	else {
		isInNeedOfTreatment = false; 
	}
}
 public String getName(){
	 return name;
 }
 public int getPainLevel(){
	 return painLevel;
 }
 public String getAilment(){
	 return ailment;
 }     
 public String toString(){
	 return "patient name: " + getName() + " ailment: " +  getAilment() + " currenet pain level: " + getPainLevel();
 }
@Override
public int compareTo(Patient p) {
	// TODO Auto-generated method stub
	double diff = this.getPainLevel() - p.getPainLevel();
	if(diff > 0){
		return 1;
	}
	else if (diff < 0){
		return-1;
	}
	else return 0;
}
}
