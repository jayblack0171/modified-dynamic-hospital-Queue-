package prob1;

import java.util.Arrays;
import java.util.Scanner;

public class PriorityQueue {
private static Patient[] patients;
private static int queueSize;
private int front;
private static int rear;
private static int numItems = 0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		System.out.println("Patient Name:");
		Scanner input = new Scanner(System.in);
		name = input.nextLine();
		System.out.println("Ailment:");
		ailment = input.nextLine();
		System.out.println("Pain Level:");
		painLevel = input.nextInt();
		*/
		Scanner input = new Scanner(System.in);
		for(int i = 0; i < patients.length; i++){
			System.out.println("Patient Name:");
			patients[i] = input.nextLine();
		}
		
		PriorityQueue q1 = new PriorityQueue(3);
		
		
		Patient p1 = new Patient("justin", "headache", 3);
		Patient p2 = new Patient("gary", "chest pain", 6);
		Patient p3 = new Patient("justin", "stomach ache", 2);
		
		q1.insert(p1);
		q1.insert(p2);
		q1.insert(p3);
		
		q1.displayTheQueue();
		q1.remove();
	}
	PriorityQueue(int size){
		queueSize = size;
		patients = new Patient[size];
		//Arrays.fill(patients, "-1"); 
	}
	public static void insert (Patient input, int painLevel){
		if(numItems == 0){
			insert(input, painLevel);
			
			patients[rear] = input;
			
			rear++;
			
			numItems++;
			
			System.out.println("Patient " + input + " has been added to the queue");
		}
		else {
			for(int i = numItems - 1; i >=0 ; i--) 
				if(Integer.parseInt(input) > Integer.parseInt(patients[i])){
					patients[i + 1] = patients[i];
				}
		}
	}
		public void remove(){
			if(numItems > 0){
				System.out.println("REMOVE " + patients[front] + " was removed");
				
				front++;
				numItems--;
				
			}
			else{
				System.out.println("the queue is clear and can now be added to ");
			}
		}
			public void displayTheQueue(){
				
				         
				
				        for(int n = 0; n < 61; n++)System.out.print("-");
				
				         
				
				        System.out.println();
				
				         
				
				        for(int n = 0; n < queueSize; n++){
				
				             
				
				            System.out.format("| %2s "+ " ", n);
				
				             
				
				        }
				
				         
				
				        System.out.println("|");
				
				         
				
				        for(int n = 0; n < 61; n++)System.out.print("-");
				
				         
				
				        System.out.println();
				
				         
				
				        for(int n = 0; n < queueSize; n++){
				
				             
				
				             
				
				            if(patients[n].equals("-1")) System.out.print("|     ");
				
				             
				
				            else System.out.print(String.format("| %2s "+ " ", patients[n]));
			
				        }
				
				         
				
				        System.out.println("|");
				
				         
				
				        for(int n = 0; n < 61; n++)System.out.print("-");
				
				         
				
				        System.out.println();
				
				         
				
				        // Number of spaces to put before the F
				
				         
				
				        int spacesBeforeFront = 3*(2*(front+1)-1);
				
				         
				
				        for(int k = 1; k < spacesBeforeFront; k++)System.out.print(" ");
				
				         
				
				        System.out.print("F");
				
				         
				
				        // Number of spaces to put before the R
				
				         
				
				        int spacesBeforeRear = (2*(3*rear)-1) - (spacesBeforeFront);
				
				         
				
				        for(int l = 0; l < spacesBeforeRear; l++)System.out.print(" ");
				
				         
				
				        System.out.print("R");
				
				         
				
				        System.out.println("\n");
				
				     
				
				}

		}
	

