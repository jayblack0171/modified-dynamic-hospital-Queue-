package prob1;
import java.util.*;
import java.util.Scanner;
public class Patient implements Comparable<Patient>{
protected static String name;
protected static String ailment;
protected static int painLevel;
protected boolean isInNeedOfTreatment;


public Patient(String name, String ailment, int painLevel) {
	// TODO Auto-generated constructor stub

	
	
	this.name = name;
	this.ailment = ailment;
	this.painLevel = painLevel;
	
	if( painLevel >= 10 || painLevel >= 5){
		isInNeedOfTreatment = true;
}
	else {
		isInNeedOfTreatment = false; 
	}
}
 public String getName(){
	 return name;
 }
 public int getPainLevel(){
	 return painLevel;
 }
 public String getAilment(){
	 return ailment;
 }     
 public String toString(){
	 return "patient name: ," + getName() + " ailment: ," +  getAilment() + " currenet pain level: ," + getPainLevel();
 }
@Override
public int compareTo(Patient otherPatient) {
	// TODO Auto-generated method stub
	double diff = this.getPainLevel() - otherPatient.getPainLevel();
	if(diff <  0){
		return -1;
	}
	else if (diff > 0){
		return 1;
	}
	else return 0;
}
}
