package prob1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class PriorityQueue extends Patient{
private static ArrayList <Patient> patients;
private static int queueSize;
private int front;
private static int rear;
private static int numItems = 0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue q1 = new PriorityQueue(3);
		Scanner input = new Scanner(System.in);
		
		System.out.println("Patient Name:");
		//Scanner input = new Scanner(System.in);
		name = input.nextLine();
		System.out.println("Ailment:");
		ailment = input.nextLine();
		System.out.println("Pain Level:");
		painLevel = input.nextInt();
		
		Patient p1 = new Patient(name, ailment, painLevel);
		//q1.insert(p1);
		//PriorityQueue q1 = new PriorityQueue(3);
		q1.insert(p1);
		// input = new Scanner(System.in);
		for(int i = 0; i < patients.size(); i++){
			
			//patients[i] = input.nextLine();
		}
		
		//PriorityQueue q1 = new PriorityQueue(3);
		
		/*
		Patient p1 = new Patient("justin", "headache", 3);
		Patient p2 = new Patient("gary", "chest pain", 6);
		Patient p3 = new Patient("montrez", "stomach ache", 2);
		
		q1.insert(p1, "justin", "headache", 3);
		q1.insert(p2,"gary", "chest pain", 6);
		q1.insert(p3,"montrez", "stomach ache", 2);
		*/
		q1.displayTheQueue();
		q1.remove();
	}
	PriorityQueue(int size){
		super(name, ailment, painLevel);
		queueSize = size;
		patients = new ArrayList <Patient>();
		//Arrays.fill(patients, "-1"); 
	}
	public static void insert ( Patient input){
		if(numItems == 0){
			patients[rear] = input;
			if (patients[rear].compareTo(patients[rear-1]) > 0){
				
			}
				

			rear++;
			
			numItems++;
			//insert(input);
			
			
			
			System.out.println("Patient " + input + " has been added to the queue");
		}
		else {
			for(int i = numItems - 1; i >=0 ; i--) 
				//if(Integer.parseInt(input) > Integer.parseInt(patients[i])){
					patients[i + 1] = patients[i];
				}
		//System.out.println("Patient " + input + " has been added to the queue");
		}
	//}
		public void remove(){
			if(numItems > 0){
				System.out.println("REMOVE " + patients[front] + " was removed");
				
				front++;
				numItems--;
				
			}
			else{
				System.out.println("the queue is clear and can now be added to ");
			}
		}
			public void displayTheQueue(){
				
				         
				
				        for(int n = 0; n < 61; n++)System.out.print("-");
				
				         
				
				        System.out.println();
				
				         
				
				        for(int n = 0; n < queueSize; n++){
				
				             
				
				            System.out.format("| %2s "+ " ", n);
				
				             
				
				        }
				
				         
				
				        System.out.println("|");
				
				         
				
				        for(int n = 0; n < 61; n++)System.out.print("-");
				
				         
				
				        System.out.println();
				
				         
				
				        
				        for (int n = 0; n < patients.length; n++){
				        	if (patients[n] != null){
				        		System.out.print(String.format("| %2s "+ " ", patients[n]));
				        	}
				        }
				             
				
				             
				        /*for(int n = 0; n < queueSize; n++){
				            //if(patients[n].equals("-1")) System.out.print("|     ");
				        	if(patients[n].equals("-1")) System.out.print("|     ");
				
				             
				
				            else System.out.print(String.format("| %2s "+ " ", patients[n]));
			
				        }
				        */
				
				         
				
				        System.out.println("|");
				
				         
				
				        for(int n = 0; n < 61; n++)System.out.print("-");
				
				         
				
				        System.out.println();
				
				         
				
				        // Number of spaces to put before the F
				
				         
				
				        int spacesBeforeFront = 3*(2*(front+1)-1);
				
				         
				
				        for(int k = 1; k < spacesBeforeFront; k++)System.out.print(" ");
				
				         
				
				        System.out.print("F");
				
				         
				
				        // Number of spaces to put before the R
				
				         
				
				        int spacesBeforeRear = (2*(3*rear)-1) - (spacesBeforeFront);
				
				         
				
				        for(int l = 0; l < spacesBeforeRear; l++)System.out.print(" ");
				
				         
				
				        System.out.print("R");
				
				         
				
				        System.out.println("\n");
				
				     
				
				}

		}
	

